https://www.figma.com/design/2j1HGzgvM0oV5oMyhotY0K/My-Favorite-Food/duplicate


My Favorite Food

Chili Hotdog

Plain food dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis


#맛있습니다
#와~ 놀랍네요!
#굳굳


Shake Shake Burger

Shake Shake Burger dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis


#빵이 부드러워요
#패티 두꺼비
#맛집


Superior Pizza

Superior Pizza dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis


#라지한판
#치즈가 쭈~욱
